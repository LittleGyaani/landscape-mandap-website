
<!--=========================*
Scripts
*===========================-->

<!-- Jquery Js -->
<script src="<?= $baseURI; ?>/assets/js/jquery.min.js?v=1.1" type="text/javascript"></script>
<!-- Jquery Js -->
<script src="<?= $baseURI; ?>/assets/js/scripts.min.js?v=1.1" type="text/javascript"></script>
<!-- Main Js -->
<script src="<?= $baseURI; ?>/assets/js/main.min.js?v=1.1" type="text/javascript"></script>
<!-- Popper Min Js -->
<script src="<?= $baseURI; ?>/assets/js/popper.min.js?v=1.1" type="text/javascript"></script>
<!-- Bootstrap Min Js -->
<script src="<?= $baseURI; ?>/assets/js/bootstrap.min.js?v=1.1" type="text/javascript"></script>
<!-- Hover Caption -->
<script src="<?= $baseURI; ?>/assets/js/jquery.capSlide.js?v=1.1"></script>
<!-- Gallery Filter -->
<script src="<?= $baseURI; ?>/assets/js/lightgallery.min.js?v=1.1"></script>
<!-- Air Datepicker -->
<script src="<?= $baseURI; ?>/assets/js/air-datepicker.min.js?v=1.1"></script>
<!-- Include English language support Air Date Picker -->
<script src="<?= $baseURI; ?>/assets/js/i18n/air-datepicker.en.js"></script>
<!-- SWAL Library -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
<!-- Extra Js -->
<!-- <script data-cfasync="false" src="https://cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script> -->
<!-- <script src="https://ajax.cloudflare.com/cdn-cgi/scripts/95c75768/cloudflare-static/rocket-loader.min.js" data-cf-settings="9a04b72165ab4a73bc41a1e4-|49" defer=""></script> -->
<!-- Custom Js -->
<script src="<?= $baseURI; ?>/assets/js/custom.js?v=1.1" type="text/javascript"></script>
<!-- Google Translate -->
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<script>
    function googleTranslateElementInit() {
        new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
    }
</script>
