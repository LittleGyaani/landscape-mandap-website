<!--=========================*
            Meta Data
*===========================-->
<!-- Meta updated by Little Gyaani (BRAHMA) {L - https://www.linkedin.com/brahmanmohanty G - https://www.github.com/LittleGyaani T - https://www.twitter.com/LittleGyaani F - https://www.facebook.com/brahmanmohanty} W - https://www.meetlittlegyaani.com/ E - bmohanty@live.com P/W - +91 9853 233 951 -->

<!-- All Require Meta Tags Starts Here -->
<meta charset="UTF-8">
<meta name="keywords" content="property, property in India, Real Estate India, Property Sites, real estate, Makaan.com, Makaan, makan, makkan, maakan, www.makaan.com" >
<meta name="description" content="Buy, Sell, Rent residential properties online in India with India's leading online real estate company. Find all your residential needs from the list of real estate projects, apartments, flats, houses etc at JSK Infra" />
<meta name="viewport" content="width=device-width, initial-scale=1 maximum-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="author" content="LittleGyaani - BRAHMA" />
<meta name="topic" content="Overseas Education Consultants, Study Abroad, Study MBBS Abroad, VISA Provider Bhubaneswar, Education Consultants Bhubaneswar, Encore Education Bhubaneswar, Encore Bhubaneswar, Encore Group, Education At Abroad Bhubaneswar, MBBS ABROAD, AUPP, SARASWARIONLINE, ATMC, China, Bangladesh, Philippines, VISA APPLICATION ONLINE Bhubaneswar, Study In United Kingdom (UK), Study In New Zealand, Study In Canada, Study In Australia, Study In USA, Study In Ireland,Study In Germany, Study In Singapore, Study In Malaysia, Foreign Universities and Educational Institutions, GRE, GMAT, IELTS, SAT, TOEFL, VISA APPLICATION Bhubaneswar, Study Abroad Bhubaneswar, MBBS Abroad Bhubaneswar, MBBS in China, MBBS in Bangladesh, MBBS in Philippines, AUPP, ATMC, Manipal Bhubaneswar, SARASWARIONLINE.com, Encore Consulting" />
<meta name="Search_Engines" content="Google, MSN, Bing, Overture, AltaVista, Yahoo, AOL, Infoseek, LookSmart, Excite, Hotbot, Lycos, Magellan, CNET, DogPile, Ask Jeeves, Teoma, Snap, Webcrawler" />
<meta name='robots' content="INDEX, FOLLOW" />
<meta name="YahooSeeker" content="INDEX, FOLLOW" />
<meta name="msnbot" content="INDEX, FOLLOW" />
<meta name="googlebot" content="INDEX, FOLLOW" />
<meta name="copyright" content="(C) Encore Education - Encore Group." />
<meta name="owner" content="bmohanty@live.com"  />
<meta name="allow-search" content="yes"  />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="cache-control" content="max-age=0" />
<meta http-equiv="expires" content="0" />
<meta http-equiv="cache-control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Expires" content="0" />
<meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT" />
<meta http-equiv="pragma" content="no-cache" />
<meta name="rating" content="General">
<meta name="audience" content="All">
<meta name="doc-type" content="Web Page">
<meta name="doc-class" content="Published">
<meta property="og:locale" content="en_US" />
<meta property='og:title' content="Study Abroad, Study MBBS Abroad, Overseas Education Consultants in Bhubaneswar - Encore Education" />
<meta property='og:type' content="Website" />
<meta property='og:url' content="https://www.encoregroup.in/" />
<meta property="og:image" content="https://www.encoregroup.in/img/encore_app_icon.png" />
<meta property='og:image:width' content="256" />
<meta property='og:image:height' content="256" />
<meta property='og:image:type' content="image/png" />
<meta property='og:description' content="Encore Education Bhubaneswar is pinoeered in providing pathway programs like Abroad Education, Overseas education, VISA Assistantce, Foregin Studies, MBBS ABROAD and only Foreign Education Company in Bhubaneswar which provides various courses for Studying Abroad like MBBS, partnered up with programs like ATMC, AUPP, Manipal and SARASWARIONLINE to make foregin studies easier and better at cheaper costs." />

<!-- Cannonical Link -->
<link rel="canonical" href="https://www.encoregroup.in/" />
