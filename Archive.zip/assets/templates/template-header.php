<!--=========================*
            Favicon
*===========================-->
<link rel="shortcut icon" type="image/x-icon" href="assets/images/Landscape-meta-icon.png">

<!--=========================*
        Main CSS
*===========================-->
<link rel="stylesheet" href="<?= $baseURI; ?>/assets/css/styles-merged.css?v=1.1">
<link rel="stylesheet" href="<?= $baseURI; ?>/assets/css/style.min.css?v=1.1">

<!--=========================*
          Custom CSS
*===========================-->
<link href="<?= $baseURI; ?>/assets/css/custom.css?v=1.1" rel="stylesheet" type="text/css">

<!--=========================*
          Light Gallery CSS
*===========================-->
<link href="<?= $baseURI; ?>/assets/css/lightgallery.min.css?v=1.1" rel="stylesheet" type="text/css">

<!--=========================*
          Air Datepicker CSS
*===========================-->
<link href="<?= $baseURI; ?>/assets/css/air-datepicker.min.css?v=1.1" rel="stylesheet" type="text/css">

<!--=========================*
        Font Library
*===========================-->
<link href="https://fonts.googleapis.com/css?family=Crimson+Text:300,400,700|Rubik:300,400,700,900" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Berkshire+Swash&display=swap" rel="stylesheet">
